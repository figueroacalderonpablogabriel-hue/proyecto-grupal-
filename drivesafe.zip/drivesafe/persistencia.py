"""
persistencia.py
Funciones genéricas para guardar y cargar datos en archivos JSON
dentro de la carpeta data/.
"""

import json
import os

# Carpeta donde se guardan todos los archivos de datos
CARPETA_DATOS = os.path.join(os.path.dirname(__file__), "data")


def _ruta(nombre_archivo):
    """Devuelve la ruta completa de un archivo dentro de data/."""
    if not os.path.exists(CARPETA_DATOS):
        os.makedirs(CARPETA_DATOS)
    return os.path.join(CARPETA_DATOS, nombre_archivo)


def cargar(nombre_archivo):
    """Carga una lista desde un archivo JSON. Si no existe, devuelve []."""
    ruta = _ruta(nombre_archivo)
    if not os.path.exists(ruta):
        return []
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def guardar(nombre_archivo, datos):
    """Guarda una lista en un archivo JSON con formato legible."""
    ruta = _ruta(nombre_archivo)
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f, indent=4, ensure_ascii=False)
