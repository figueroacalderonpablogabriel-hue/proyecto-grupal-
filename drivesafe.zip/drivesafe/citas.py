"""
citas.py
Programación de citas, control de asistencia e historial.
Valida existencia de cliente e instructor, y disponibilidad de vehículo.
"""

from persistencia import cargar, guardar
from validaciones import pedir_texto, pedir_entero, pedir_fecha, pedir_hora
from clientes import (
    buscar_cliente,
    buscar_vehiculo,
    ARCHIVO_INSTRUCTORES,
    ARCHIVO_VEHICULOS,
)

ARCHIVO_CITAS = "citas.json"


def _buscar_instructor(documento):
    for i in cargar(ARCHIVO_INSTRUCTORES):
        if i.get("documento") == documento:
            return i
    return None


def programar_cita():
    print("\n--- Programar cita ---")

    documento_cliente = pedir_texto("Documento del cliente: ")
    cliente = buscar_cliente(documento_cliente)
    if not cliente:
        print("No existe un cliente con ese documento. Regístrelo primero.")
        return

    documento_instructor = pedir_texto("Documento del instructor: ")
    instructor = _buscar_instructor(documento_instructor)
    if not instructor:
        print("No existe un instructor con ese documento.")
        return

    placa = pedir_texto("Placa del vehículo: ").upper()
    vehiculo = buscar_vehiculo(placa)
    if not vehiculo:
        print("No existe un vehículo con esa placa.")
        return
    if not vehiculo.get("disponible", True):
        print("El vehículo no está disponible.")
        return

    fecha = pedir_fecha("Fecha (AAAA-MM-DD): ")
    hora = pedir_hora("Hora (HH:MM): ")
    duracion = pedir_entero("Duración (minutos): ", minimo=15, maximo=240)

    cita = {
        "documento_cliente": documento_cliente,
        "nombre_cliente": cliente["nombre"],
        "documento_instructor": documento_instructor,
        "nombre_instructor": instructor["nombre"],
        "placa": placa,
        "fecha": fecha,
        "hora": hora,
        "duracion": duracion,
        "asistencia": None,
        "observacion": None
    }

    citas = cargar(ARCHIVO_CITAS)
    citas.append(cita)
    guardar(ARCHIVO_CITAS, citas)

    # Marcar vehículo como ocupado
    vehiculos = cargar(ARCHIVO_VEHICULOS)
    for v in vehiculos:
        if v.get("placa") == placa:
            v["disponible"] = False
    guardar(ARCHIVO_VEHICULOS, vehiculos)

    print("Cita agendada correctamente.")


def _imprimir_cita(c):
    print("  -----------------------------")
    print(f"  Cliente:    {c['nombre_cliente']} ({c['documento_cliente']})")
    print(f"  Instructor: {c['nombre_instructor']} ({c['documento_instructor']})")
    print(f"  Vehículo:   {c['placa']}")
    print(f"  Fecha:      {c['fecha']} {c['hora']}  ({c['duracion']} min)")
    asistencia = c.get("asistencia")
    print(f"  Asistencia: {asistencia if asistencia is not None else 'pendiente'}")
    if c.get("observacion"):
        print(f"  Observación: {c['observacion']}")


def consultar_citas():
    citas = cargar(ARCHIVO_CITAS)
    if not citas:
        print("No hay citas programadas.")
        return

    print("\n¿Cómo desea filtrar?")
    print("  1. Todas")
    print("  2. Por cliente (documento)")
    print("  3. Por fecha")
    opcion = input("Opción: ").strip()

    if opcion == "2":
        documento = pedir_texto("Documento del cliente: ")
        resultado = [c for c in citas if c["documento_cliente"] == documento]
    elif opcion == "3":
        fecha = pedir_fecha("Fecha (AAAA-MM-DD): ")
        resultado = [c for c in citas if c["fecha"] == fecha]
    else:
        resultado = citas

    if not resultado:
        print("No se encontraron citas con ese criterio.")
        return

    print(f"\n--- Citas encontradas ({len(resultado)}) ---")
    for c in resultado:
        _imprimir_cita(c)


def registrar_asistencia():
    print("\n--- Registrar asistencia ---")
    documento = pedir_texto("Documento del cliente: ")
    fecha = pedir_fecha("Fecha de la cita (AAAA-MM-DD): ")

    citas = cargar(ARCHIVO_CITAS)
    encontrada = False
    for c in citas:
        if c["documento_cliente"] == documento and c["fecha"] == fecha:
            asistio = input("¿Asistió a la clase? (si / no): ").strip().lower()
            observacion = input("Observaciones del instructor: ").strip()
            c["asistencia"] = "si" if asistio == "si" else "no"
            c["observacion"] = observacion
            encontrada = True

            # Liberar el vehículo tras la práctica
            vehiculos = cargar(ARCHIVO_VEHICULOS)
            for v in vehiculos:
                if v.get("placa") == c["placa"]:
                    v["disponible"] = True
            guardar(ARCHIVO_VEHICULOS, vehiculos)
            break

    if encontrada:
        guardar(ARCHIVO_CITAS, citas)
        print("Asistencia y observaciones registradas.")
    else:
        print("No se encontró una cita para ese cliente en esa fecha.")


def historial_cliente():
    print("\n--- Historial de cliente ---")
    documento = pedir_texto("Documento del cliente: ")

    citas = cargar(ARCHIVO_CITAS)
    historial = [c for c in citas if c["documento_cliente"] == documento]

    if not historial:
        print("Este cliente no tiene prácticas registradas.")
        return

    print(f"\n--- Historial de {historial[0]['nombre_cliente']} ({len(historial)} prácticas) ---")
    for c in historial:
        _imprimir_cita(c)
