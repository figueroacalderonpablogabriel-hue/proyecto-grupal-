"""
validaciones.py
Funciones de validación reutilizables en todo el proyecto.
"""

from datetime import datetime


def pedir_texto(mensaje):
    """Pide un texto no vacío."""
    while True:
        valor = input(mensaje).strip()
        if valor:
            return valor
        print("  Este campo no puede estar vacío.")


def pedir_entero(mensaje, minimo=None, maximo=None):
    """Pide un número entero, con límites opcionales."""
    while True:
        valor = input(mensaje).strip()
        if not valor.isdigit():
            print("  Ingrese un número válido.")
            continue
        numero = int(valor)
        if minimo is not None and numero < minimo:
            print(f"  El valor debe ser mayor o igual a {minimo}.")
            continue
        if maximo is not None and numero > maximo:
            print(f"  El valor debe ser menor o igual a {maximo}.")
            continue
        return numero


def pedir_opcion(mensaje, opciones):
    """Pide un valor que esté dentro de una lista de opciones válidas."""
    opciones_lower = [o.lower() for o in opciones]
    while True:
        valor = input(mensaje).strip().lower()
        if valor in opciones_lower:
            return valor
        print(f"  Opción inválida. Use: {', '.join(opciones)}")


def pedir_fecha(mensaje):
    """Pide una fecha con formato YYY-MM-DD y valida que sea real."""
    while True:
        valor = input(mensaje).strip()
        try:
            datetime.strptime(valor, "%Y-%m-%d")
            return valor
        except ValueError:
            print("  Fecha inválida. Use el formato AAAA-MM-DD (ej: 2025-07-20).")


def pedir_hora(mensaje):
    """Pide una hora con formato HH:MM y valida que sea real."""
    while True:
        valor = input(mensaje).strip()
        try:
            datetime.strptime(valor, "%H:%M")
            return valor
        except ValueError:
            print("  Hora inválida. Use el formato HH:MM (ej: 14:30).")
