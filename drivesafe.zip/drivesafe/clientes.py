"""
clientes.py
Gestión de clientes, instructores y vehículos.
Incluye validación de documento único y persistencia en JSON.
"""

from persistencia import cargar, guardar
from validaciones import pedir_texto, pedir_entero, pedir_opcion

ARCHIVO_CLIENTES = "clientes.json"
ARCHIVO_INSTRUCTORES = "instructores.json"
ARCHIVO_VEHICULOS = "vehiculos.json"


# ---------------------- CLIENTES ----------------------

def documento_existe(documento, lista):
    """Verifica si un documento ya está registrado en una lista."""
    return any(item.get("documento") == documento for item in lista)


def registrar_cliente():
    clientes = cargar(ARCHIVO_CLIENTES)

    print("\n--- Registrar cliente ---")
    documento = pedir_texto("Documento: ")

    if documento_existe(documento, clientes):
        print("Ya existe un cliente con ese documento.")
        return

    nombre = pedir_texto("Nombre: ")
    edad = pedir_entero("Edad: ", minimo=15, maximo=100)
    tipo_vehiculo = pedir_opcion("Tipo de vehículo (moto o carro): ", ["moto", "carro"])

    cliente = {
        "documento": documento,
        "nombre": nombre,
        "edad": edad,
        "tipo_vehiculo": tipo_vehiculo
    }
    clientes.append(cliente)
    guardar(ARCHIVO_CLIENTES, clientes)
    print("Cliente registrado correctamente.")


def consultar_clientes():
    clientes = cargar(ARCHIVO_CLIENTES)
    if not clientes:
        print("No hay clientes registrados.")
        return
    print("\n--- Lista de clientes ---")
    for c in clientes:
        print(f"  {c['documento']} | {c['nombre']} | {c['edad']} años | {c['tipo_vehiculo']}")


def buscar_cliente(documento):
    clientes = cargar(ARCHIVO_CLIENTES)
    for c in clientes:
        if c.get("documento") == documento:
            return c
    return None


# ---------------------- INSTRUCTORES ----------------------

def registrar_instructor():
    instructores = cargar(ARCHIVO_INSTRUCTORES)

    print("\n--- Registrar instructor ---")
    documento = pedir_texto("Documento: ")

    if documento_existe(documento, instructores):
        print("Ya existe un instructor con ese documento.")
        return

    nombre = pedir_texto("Nombre: ")
    ciudad = pedir_texto("Ciudad: ")
    edad = pedir_entero("Edad: ", minimo=18, maximo=100)
    especialidad = pedir_opcion("Especialidad (moto o carro): ", ["moto", "carro"])

    instructor = {
        "documento": documento,
        "nombre": nombre,
        "ciudad": ciudad,
        "edad": edad,
        "especialidad": especialidad
    }
    instructores.append(instructor)
    guardar(ARCHIVO_INSTRUCTORES, instructores)
    print("Instructor registrado correctamente.")


def consultar_instructores():
    instructores = cargar(ARCHIVO_INSTRUCTORES)
    if not instructores:
        print("No hay instructores registrados.")
        return
    print("\n--- Lista de instructores ---")
    for i in instructores:
        print(f"  {i['documento']} | {i['nombre']} | {i['ciudad']} | especialidad: {i['especialidad']}")


# ---------------------- VEHÍCULOS ----------------------

def registrar_vehiculo():
    vehiculos = cargar(ARCHIVO_VEHICULOS)

    print("\n--- Registrar vehículo ---")
    placa = pedir_texto("Placa: ").upper()

    if any(v.get("placa") == placa for v in vehiculos):
        print("Ya existe un vehículo con esa placa.")
        return

    tipo = pedir_opcion("Tipo (moto o carro): ", ["moto", "carro"])
    propietario = pedir_opcion("Propiedad (publico o cliente): ", ["publico", "cliente"])

    vehiculo = {
        "placa": placa,
        "tipo": tipo,
        "propietario": propietario,
        "disponible": True
    }

    if propietario == "cliente":
        documento = pedir_texto("Documento del cliente dueño: ")
        vehiculo["documento_cliente"] = documento

    vehiculos.append(vehiculo)
    guardar(ARCHIVO_VEHICULOS, vehiculos)
    print("Vehículo registrado correctamente.")


def consultar_vehiculos():
    vehiculos = cargar(ARCHIVO_VEHICULOS)
    if not vehiculos:
        print("No hay vehículos registrados.")
        return
    print("\n--- Lista de vehículos ---")
    for v in vehiculos:
        estado = "disponible" if v.get("disponible", True) else "ocupado"
        print(f"  {v['placa']} | {v['tipo']} | {v['propietario']} | {estado}")


def buscar_vehiculo(placa):
    vehiculos = cargar(ARCHIVO_VEHICULOS)
    for v in vehiculos:
        if v.get("placa") == placa.upper():
            return v
    return None
