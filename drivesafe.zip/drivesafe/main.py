"""
main.py
Punto de entrada de la aplicación Academia DriveSafe.
Ejecutar con:  python main.py
"""

from clientes import (
    registrar_cliente,
    consultar_clientes,
    registrar_instructor,
    consultar_instructores,
    registrar_vehiculo,
    consultar_vehiculos,
)
from citas import (
    programar_cita,
    consultar_citas,
    registrar_asistencia,
    historial_cliente,
)


def menu():
    while True:
        print("\n========================================")
        print("      ACADEMIA DRIVESAFE - MENÚ")
        print("========================================")
        print(" 1. Registrar cliente")
        print(" 2. Consultar clientes")
        print(" 3. Registrar instructor")
        print(" 4. Consultar instructores")
        print(" 5. Registrar vehículo")
        print(" 6. Consultar vehículos")
        print(" 7. Programar cita")
        print(" 8. Consultar citas")
        print(" 9. Registrar asistencia")
        print("10. Historial de cliente")
        print("11. Salir")

        opcion = input("Seleccione una opción: ").strip()

        if opcion == "1":
            registrar_cliente()
        elif opcion == "2":
            consultar_clientes()
        elif opcion == "3":
            registrar_instructor()
        elif opcion == "4":
            consultar_instructores()
        elif opcion == "5":
            registrar_vehiculo()
        elif opcion == "6":
            consultar_vehiculos()
        elif opcion == "7":
            programar_cita()
        elif opcion == "8":
            consultar_citas()
        elif opcion == "9":
            registrar_asistencia()
        elif opcion == "10":
            historial_cliente()
        elif opcion == "11":
            print("Programa finalizado. ¡Hasta luego!")
            break
        else:
            print("Opción inválida. Intente de nuevo.")


if __name__ == "__main__":
    menu()
