# Academia DriveSafe

Aplicación de consola en Python para gestionar las prácticas de conducción
(moto y carro) de la academia DriveSafe: registro de clientes, instructores y
vehículos, programación de citas, control de asistencia e historial de prácticas.
Toda la información se guarda de forma persistente en archivos JSON locales.

## Requisitos

- Python 3.8 o superior.
- No se necesitan dependencias externas (solo la librería estándar: `json`, `os`, `datetime`).

## Estructura del proyecto

```
drivesafe/
├── main.py            # Punto de entrada y menú principal
├── clientes.py        # Registro/consulta de clientes, instructores y vehículos
├── citas.py           # Programación de citas, asistencia e historial
├── validaciones.py    # Funciones de validación (texto, número, fecha, hora, opciones)
├── persistencia.py    # Guardar y cargar datos en JSON
├── README.md
└── data/              # Archivos JSON generados automáticamente
    ├── clientes.json
    ├── instructores.json
    ├── vehiculos.json
    └── citas.json
```

## Cómo ejecutar

Desde la carpeta del proyecto:

```bash
python main.py
```

(o `python3 main.py` según el sistema).

La carpeta `data/` y sus archivos se crean solos la primera vez que se registra información.

## Menú de opciones

```
 1. Registrar cliente
 2. Consultar clientes
 3. Registrar instructor
 4. Consultar instructores
 5. Registrar vehículo
 6. Consultar vehículos
 7. Programar cita
 8. Consultar citas
 9. Registrar asistencia
10. Historial de cliente
11. Salir
```

## Validaciones incluidas

- **Documento único**: no se puede registrar dos clientes (ni dos instructores) con el mismo documento, ni dos vehículos con la misma placa.
- **Tipo/especialidad**: solo se aceptan los valores `moto` o `carro`.
- **Edad**: numérica y dentro de un rango razonable.
- **Fecha**: formato `AAAA-MM-DD` validado como fecha real.
- **Hora**: formato `HH:MM` validado.
- **Duración**: numérica (15 a 240 minutos).
- **Disponibilidad**: al programar una cita el vehículo debe estar disponible; queda ocupado hasta registrar la asistencia.
- Al programar una cita se verifica que el cliente, el instructor y el vehículo existan previamente.

## Ejemplo de uso

1. **Registrar un cliente** (opción 1):
   ```
   Documento: 12345
   Nombre: Juan Perez
   Edad: 25
   Tipo de vehículo (moto o carro): moto
   ```

2. **Registrar un instructor** (opción 3):
   ```
   Documento: 99999
   Nombre: Carlos Ruiz
   Ciudad: Bogota
   Edad: 40
   Especialidad (moto o carro): moto
   ```

3. **Registrar un vehículo** (opción 5):
   ```
   Placa: ABC123
   Tipo (moto o carro): moto
   Propiedad (publico o cliente): publico
   ```

4. **Programar una cita** (opción 7):
   ```
   Documento del cliente: 12345
   Documento del instructor: 99999
   Placa del vehículo: ABC123
   Fecha (AAAA-MM-DD): 2025-08-10
   Hora (HH:MM): 14:30
   Duración (minutos): 60
   ```

5. **Consultar citas** (opción 8): permite ver todas, filtrar por cliente o por fecha.

6. **Registrar asistencia** (opción 9): se indica documento y fecha de la cita, si asistió y una observación.

7. **Historial de cliente** (opción 10): muestra todas las prácticas de un cliente.

## Persistencia

Los datos se almacenan en formato JSON en la carpeta `data/`. Al cerrar y volver
a abrir el programa, toda la información se conserva y se carga automáticamente.
